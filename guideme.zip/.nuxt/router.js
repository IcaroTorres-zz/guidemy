import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _04f56a64 = () => import('..\\pages\\detailedsearch.vue' /* webpackChunkName: "pages_detailedsearch" */).then(m => m.default || m)
const _7404728e = () => import('..\\pages\\dashboard.vue' /* webpackChunkName: "pages_dashboard" */).then(m => m.default || m)
const _3a231450 = () => import('..\\pages\\archived.vue' /* webpackChunkName: "pages_archived" */).then(m => m.default || m)
const _334339aa = () => import('..\\pages\\dailymeetings.vue' /* webpackChunkName: "pages_dailymeetings" */).then(m => m.default || m)
const _2828a38e = () => import('..\\pages\\signup.vue' /* webpackChunkName: "pages_signup" */).then(m => m.default || m)
const _a9d6232a = () => import('..\\pages\\project\\_id\\index.vue' /* webpackChunkName: "pages_project__id_index" */).then(m => m.default || m)
const _decfa962 = () => import('..\\pages\\task\\_id.vue' /* webpackChunkName: "pages_task__id" */).then(m => m.default || m)
const _1b9556b7 = () => import('..\\pages\\daily\\_id.vue' /* webpackChunkName: "pages_daily__id" */).then(m => m.default || m)
const _097bd34f = () => import('..\\pages\\project\\_id\\results.vue' /* webpackChunkName: "pages_project__id_results" */).then(m => m.default || m)
const _ae6b3a68 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)
const _63219ab8 = () => import('..\\pages\\_user.vue' /* webpackChunkName: "pages__user" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/detailedsearch",
			component: _04f56a64,
			name: "detailedsearch"
		},
		{
			path: "/dashboard",
			component: _7404728e,
			name: "dashboard"
		},
		{
			path: "/archived",
			component: _3a231450,
			name: "archived"
		},
		{
			path: "/dailymeetings",
			component: _334339aa,
			name: "dailymeetings"
		},
		{
			path: "/signup",
			component: _2828a38e,
			name: "signup"
		},
		{
			path: "/project/:id?",
			component: _a9d6232a,
			name: "project-id"
		},
		{
			path: "/task/:id?",
			component: _decfa962,
			name: "task-id"
		},
		{
			path: "/daily/:id?",
			component: _1b9556b7,
			name: "daily-id"
		},
		{
			path: "/project/:id?/results",
			component: _097bd34f,
			name: "project-id-results"
		},
		{
			path: "/",
			component: _ae6b3a68,
			name: "index"
		},
		{
			path: "/:user",
			component: _63219ab8,
			name: "user"
		}
    ],
    
    
    fallback: false
  })
}
