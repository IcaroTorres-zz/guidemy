export default {
  mounted () {
    this.init()
  },
  methods: {
    init () {
      this.clearError()
    }
  }
}
